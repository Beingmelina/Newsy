let cachedApiKey = null;
let cachedApiKeyExpiry = 0;

async function getElevenLabsApiKey() {
  if (cachedApiKey && Date.now() < cachedApiKeyExpiry) {
    return cachedApiKey;
  }

  const hostname = process.env.REPLIT_CONNECTORS_HOSTNAME;
  if (!hostname) {
    throw new Error('REPLIT_CONNECTORS_HOSTNAME not set - ElevenLabs connector not configured');
  }

  const xReplitToken = process.env.REPL_IDENTITY
    ? 'repl ' + process.env.REPL_IDENTITY
    : process.env.WEB_REPL_RENEWAL
    ? 'depl ' + process.env.WEB_REPL_RENEWAL
    : null;

  if (!xReplitToken) {
    throw new Error('Replit token not found');
  }

  const conn = await fetch(
    'https://' + hostname + '/api/v2/connection?include_secrets=true&connector_names=elevenlabs',
    {
      headers: {
        'Accept': 'application/json',
        'X-Replit-Token': xReplitToken
      }
    }
  ).then(r => r.json()).then(d => d.items?.[0]);

  if (!conn || !conn.settings.api_key) {
    throw new Error('ElevenLabs not connected');
  }

  cachedApiKey = conn.settings.api_key;
  cachedApiKeyExpiry = Date.now() + 5 * 60 * 1000;
  return cachedApiKey;
}

const VOICE_MAP = {
  'male-american': 'nPczCjzI2devNBz1zQrb',
  'male-british': 'onwK4e9ZLuTAKqWW03F9',
  'female-american': '21m00Tcm4TlvDq8ikWAM',
  'female-british': 'MF3mGyEYCl7XYWbV9V6O',
  'ash': 'nPczCjzI2devNBz1zQrb',
  'coral': '21m00Tcm4TlvDq8ikWAM',
};

async function textToSpeech(text, voice = 'ash', accent = 'american') {
  console.log('TTS request - text length:', text.length, 'voice:', voice, 'accent:', accent);

  const apiKey = await getElevenLabsApiKey();

  const gender = (voice === 'coral') ? 'female' : 'male';
  const voiceKey = `${gender}-${accent}`;
  const voiceId = VOICE_MAP[voiceKey] || VOICE_MAP[voice] || VOICE_MAP['ash'];

  const response = await fetch(
    `https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`,
    {
      method: 'POST',
      headers: {
        'xi-api-key': apiKey,
        'Content-Type': 'application/json',
        'Accept': 'audio/mpeg'
      },
      body: JSON.stringify({
        text: text,
        model_id: 'eleven_turbo_v2_5',
        voice_settings: {
          stability: 0.65,
          similarity_boost: 0.8,
          style: 0.2,
          use_speaker_boost: true
        }
      })
    }
  );

  if (!response.ok) {
    const errText = await response.text();
    console.error('ElevenLabs TTS error:', response.status, errText);
    throw new Error('ElevenLabs TTS failed: ' + errText);
  }

  const arrayBuffer = await response.arrayBuffer();
  const buffer = Buffer.from(arrayBuffer);
  console.log('TTS success - audio bytes:', buffer.length);
  return buffer;
}

module.exports = { textToSpeech };
